<?php

      include('functions/connection.php');
  session_start();

 if(isset($_POST['directory_name'])){
      $directory_name = $_POST['directory_name'];
      $dir = "apps/".$directory_name;
    if(!mkdir($dir)){
            die('Failed to Create Folders.....');
 } 
}

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Basic Handler | Jcrop Demo</title>
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8" />

<script src="functions/js/jquery.min.js"></script>
<script src="functions/js/jquery.Jcrop.js"></script>


<link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">


<script type="text/javascript">

  jQuery(function($){

    var jcrop_api;

    $('#target').Jcrop({
      onChange:   showCoords,
      onSelect:   showCoords,
      onRelease:  clearCoords
    },function(){
      jcrop_api = this;
    });

    $('#coords').on('change','input',function(e){
      var x1 = $('#x1').val(),
          x2 = $('#x2').val(),
          y1 = $('#y1').val(),
          y2 = $('#y2').val();
      jcrop_api.setSelect([x1,y1,x2,y2]);
    });
     $('#dtarget').Jcrop({
      onChange:   dshowCoords,
      onSelect:   dshowCoords,
      onRelease:  dclearCoords
    },function(){
      jcrop_api = this;
    });
 $('#ptarget').Jcrop({
      onChange:   pshowCoords,
      onSelect:   pshowCoords,
      onRelease:  pclearCoords
    },function(){
      jcrop_api = this;
    });
  });

  // Simple event handler, called from onChange and onSelect
  // event handlers, as per the Jcrop invocation above
  function showCoords(c)
  {
    $('#x1').val(c.x);
    $('#y1').val(c.y);
    $('#x2').val(c.x2);
    $('#y2').val(c.y2);
    $('#w').val(c.w);
    $('#h').val(c.h);
  };

function dshowCoords(c)
  {
    $('#dx1').val(c.x);
    $('#dy1').val(c.y);
    $('#dx2').val(c.x2);
    $('#dy2').val(c.y2);
    $('#dw').val(c.w);
    $('#dh').val(c.h);
  };

  function clearCoords()
  {
    $('#coords input').val('');
  };


  function dclearCoords()
  {
    $('#dcoords input').val('');
  };
function pshowCoords(c)
  {
    $('#px1').val(c.x);
    $('#py1').val(c.y);
    $('#px2').val(c.x2);
    $('#py2').val(c.y2);
    $('#pw').val(c.w);
    $('#ph').val(c.h);
  };
 function pclearCoords()
  {
    $('#pcoords input').val('');
  };

</script>

<link rel="stylesheet" href="functions/css/jquery.Jcrop.css" type="text/css" />

</head>
<body>


  <!-- For HEAD -->
  <h1 class="display-3" align="center"> Crop Header</h1>
  <br/>
  <img src="apps/photos/<?php echo $_SESSION['iname']; ?>.jpg" id="target" alt="[Jcrop Example]" />

  <!-- This is the form that our event handler fills -->
  <form id="coords"
    class="coords"
    
    action="last.php" method="post">

    <div class="inline-labels">
    <label>X1 <input type="text" size="4" id="x1" name="x1" /></label>
    <label>Y1 <input type="text" size="4" id="y1" name="y1" /></label>
    <label>X2 <input type="text" size="4" id="x2" name="x2" /></label>
    <label>Y2 <input type="text" size="4" id="y2" name="y2" /></label>
    <label>W <input type="text" size="4" id="w" name="w" /></label>
    <label>H <input type="text" size="4" id="h" name="h" /></label>
    </div>
    <br>
    <input type="submit"  name="lastsubmit">
  </form>
  </br>
  
  <!-- Description -->
 <h1 class="display-3" align="center"> Crop Description</h1>
  <br/>
  <img src="apps/photos/<?php echo $_SESSION['iname']; ?>.jpg" id="dtarget" alt="[Jcrop Example]" />

  <!-- This is the form that our event handler fills -->
  <form id="dcoords"
    class="dcoords"
    
    action="last.php" method="post">

    <div class="inline-labels">
    <label>X1 <input type="text" size="4" id="dx1" name="dx1" /></label>
    <label>Y1 <input type="text" size="4" id="dy1" name="dy1" /></label>
    <label>X2 <input type="text" size="4" id="dx2" name="dx2" /></label>
    <label>Y2 <input type="text" size="4" id="dy2" name="dy2" /></label>
    <label>W <input type="text" size="4" id="dw" name="dw" /></label>
    <label>H <input type="text" size="4" id="dh" name="dh" /></label>
    </div>
    <br>
    <input type="submit"  name="lastsubmit">
  </form>
  </br>
  <!-- Crop Header -->
   <h1 class="display-3" align="center"> Crop For Profile Picture</h1>
  <br/>
  <img src="apps/photos/<?php echo $_SESSION['iname']; ?>.jpg" id="ptarget" alt="[Jcrop Example]" />

  <!-- This is the form that our event handler fills -->
  <form id="pcoords"
    class="pcoords"
    
    action="last.php" method="post">

    <div class="inline-labels">
    <label>X1 <input type="text" size="4" id="px1" name="px1" /></label>
    <label>Y1 <input type="text" size="4" id="py1" name="py1" /></label>
    <label>X2 <input type="text" size="4" id="px2" name="px2" /></label>
    <label>Y2 <input type="text" size="4" id="py2" name="py2" /></label>
    <label>W <input type="text" size="4" id="pw" name="pw" /></label>
    <label>H <input type="text" size="4" id="ph" name="ph" /></label>
    </div>
    <br>
    <input type="submit"  name="lastsubmit">
  </form>
  </br>

</body>
</html>

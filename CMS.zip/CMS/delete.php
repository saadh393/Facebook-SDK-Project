<?php 
include('functions/connection.php');
session_start();
if (isset($_POST['delete'])) {
	$id = $_SESSION['id'];		
			 mysql_select_db("cms");
				 $res = mysql_query("SELECT * FROM pages WHERE id = '$id' ");
							
			$row = mysql_fetch_assoc($res);
			
					$sql  = "DELETE FROM `pages` WHERE id = '$id'";
					$res  = mysql_query($sql) or die(mysql_error());
					header("location:functions/maintain.php");
				
				
}

 ?>
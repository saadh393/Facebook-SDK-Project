<?php 
session_start();
if(isset($_GET['edit'])){
    $_SESSION['id'] = $_GET['edit'];
}


include('functions/connection.php');
			if ( isset( $_GET['edit'])){
				 global $id;
				$id = $_SESSION['id'];
				 mysql_select_db("cms");
				 $res = mysql_query("SELECT * FROM pages WHERE id = '$id' ");
				 $row = mysql_fetch_assoc($res);
                  
				mysql_select_db("cms");
							
				if($row['visible'] == '1'){
					$visiblity = "Hide This Content";
                    $btn = "btn btn-danger";
				}elseif ($row['visible'] == '0'){
					$visiblity = "Show This Content";
                    $btn = "btn btn-success";
                    $name = "mv";
				}
       
				}
                if(isset($_POST['visible'])){
                   
                    
                             mysql_select_db("cms");
                             $id = $_SESSION['id'];
                               $sql  = "UPDATE pages SET visible = 1 WHERE id = '$id'";
                               mysql_query($sql);
                             
                    echo mysql_error();
                        }
                  
              
            if(isset($_POST['mv'])){
                       
                    
                             mysql_select_db("cms");
                             $id = $_SESSION['id'];
                               $sql  = "UPDATE pages SET visible = 0 WHERE id = '$id'";
                               mysql_query($sql);
                              }
                   
                

 ?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Simple Sidebar - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

      <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="/cms/admin.php">
                        Clown Share CMS
                    </a>
                </li>
                <li>
                    <a href="admin.php">Home</a>
                </li>
                <li>
                    <a href="admin.php?page=Submit+A+New+App">Submit A New App</a>
                </li>
                <li>
                    <a href="admin.php?page=Maintain+Apps">Maintain Apps</a>
                </li>
                <li>
                    <a href="admin.php?page=Create+A+New+App">Create A New App</a>
                </li>
                <li>
                   
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>Edit Your Posts</h1>
                        <form action="edit.php" method="POST">
                        <label for="inputdefault">Head</label>
 	<input type="name" class="form-control" style="height:50px;" rows="5" name="newname" value="<?php echo $row['Head']; ?>" rows="4" cols="50">

    <br/>
    <div class="form-group">
     <label for="inputdefault">Paragraph</label>
 	<input type="name" class="form-control" style="height:50px;" rows="5" name="newparagraph" value="<?php echo $row['paragraph']; ?>">
    </div>
 	<input type="hidden" name="id" value="<?php echo $row['id']; ?>"><br/> 	<input type="submit" name=" Update " class="btn btn-primary">
 </form>
 <form method="POST" action="edit.php"><br/><br/><br/>
 	Visible: <input type="submit" name="visible" value="<?php echo $visiblity; ?>" class="<?php echo $btn; ?>">

 </form><br/><br/><br/><br/><br/>
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Toggle Menu</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>

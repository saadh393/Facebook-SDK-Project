<?php 

        $dbhost= "localhost";
        $dbuser =  "root";
        $dbpass = "";
        $dbname ="cms";

        $connection = mysql_connect($dbhost,$dbuser,$dbpass,$dbname);

        //Error Handling 
        if (!$connection){
         echo ('Could not connect: ' . mysql_error()); 
         exit();
        }else{
            echo "Connected";
            
        }

        
 ?>

   <?php 
 //Perform Database Query
        mysql_select_db('cms');
        $query = "SELECT * FROM pages WHERE id=12";
        $res = mysql_query($query,$connection);
?>
                <?php //Test if  there is any Error 
        while($row = mysql_fetch_array($res)){

 
    echo $row['Head']."</br>" ;


     } ?>
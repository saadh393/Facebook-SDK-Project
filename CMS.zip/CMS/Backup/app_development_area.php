<?php
      include('functions/connection.php');
  

 if(isset($_POST['directory_name'])){
      $directory_name = $_POST['directory_name'];
      $dir = "apps/".$directory_name;
    if(!mkdir($dir)){
            die('Failed to Create Folders.....');
 } 
}

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Basic Handler | Jcrop Demo</title>
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8" />

<form action="upload.php" method="post" enctype="multipart/form-data">
Select image to upload:<br>
    <input type="file" name="fileToUpload" id="fileToUpload"><br>
    <input type="name" name="imagename" value="<?php echo $directory_name; ?>"><br>
    <input type="submit" class="btn btn-primary" value="Upload Image" name="submit">
</form>

</body>
</html>

<?php
session_start();

if(isset($_POST['imagename'])){
	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "apps/photos/".$_POST['imagename'].".jpg");
	echo "Upoladed!";
	$_SESSION['iname'] = $_POST['imagename'];
	header("location: app_development_area2.php");
}else{
	echo "Dear, ****! Are you searching app bug? ";
}
?>

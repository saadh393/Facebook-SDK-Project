<?php
session_start();
if(isset($_POST['lastsubmit'])){
	echo "<pre>";
	print_r($_POST);
	echo "</pre>";
}
echo "<br>";
$dir = scandir("copy");
	unset($dir[0], $dir[1]);sort($dir);
	echo "<pre>";
	print_r($dir);
	echo "</pre>";

foreach ($dir as $key => $value) {
	if($value=="index2.php"){
		continue;
	}
	copy("copy/".$value, "apps/".$_SESSION['iname']."/".$value);
}
echo "<br>Files Has been copied Successfully.";

//Changing Index2
?>
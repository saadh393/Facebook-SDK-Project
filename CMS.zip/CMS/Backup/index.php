<?php include("functions/connection.php") ?>
<?php include("functions/post.php") ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Clown Share </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/3-col-portfolio.css" rel="stylesheet">

   
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="http://bn.clownshare.com"><span style="float: right;">Clown Share </span>
            <img src="cl.png" style="max-height: 70px; margin-top: -10px; " alt="ClownShare" ></img></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="float: right;">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="http://bn.clownshare.com">Bangla App</a>
                    </li>
                    <li>
                        <a href="http://en.clownshare.com">English App</a>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container" style="margin-top:100px;">


<?php $calling_function =scrollAll(5, 10);?>

       

        <!-- Pagination -->
      
        <!-- /.row -->

<br><br><br>
<div class="container">
    <div class="row">
        
    </div>
</div>
        <!-- Footer -->
             <footer><br><br><br>
                    <div class="row">
                        <div class="col-lg-12">
                            <center><p>Copyright &copy; 2016 <a href="http://clownshare.com">Clownshare.com </a></p></center>
                        </div>
                    </div>
                    <!-- /.row -->
                </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
<?php
function scrollAll(){
        global $connection;
        mysql_select_db("cms");
        $query = "SELECT * FROM pages WHERE visible = 1 ORDER BY id DESC";
        $res = mysql_query($query,$connection);
        $row = array();
        $i=4;
        $z = 1;
        while($row = mysql_fetch_assoc($res)){
           $box = <<<CODE
            <div class="col-md-4 portfolio-item">
                <a href="apps/{$row['link']}">
                    <img class="img-responsive" src="banner/{$row['image url']}" alt="">
                </a>
                <h3>
                    <a href="apps/{$row['link']}">{$row['Head']}</a>
                </h3>
                <p>{$row['paragraph']}</p>
            </div>
       
CODE;
if(($i%3)==0){
    echo '<div class="row">';
}
echo $box;
if(($i%3)==0){
    
    echo '</div>  <hr><br/>';
}

   $i++;     
        }

}
?>
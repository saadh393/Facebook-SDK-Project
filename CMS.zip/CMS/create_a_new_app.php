  <?php 
   include('functions/connection.php');
 //include('functions/error.php');
   	if (isset($_POST['next'])) {

   		$directory_name = $_POST['directory_name'];
   		//$upload_image   = $_POST['upload_image'];
   				
   		
   		$dir = "../apps/".$directory_name;
   		// if(!mkdir($directory_name, 007,true)){
   		// 	die('Failed to Create Folders.....');
   		// }
   			if (mkdir($dir, 007,true)) {
   				include('app_development_area.php');
   			}else{
   				  //error("Unable to create folder");
   				die('Failed to Create Folders.....');
   			}

   	}
?><head>	
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/simple-sidebar.css" rel="stylesheet">
		
		
	</head>
			

	
	
	<h1 align="center"> Create A New App</h1>
	<!-- action="admin.php?page=Create+A+New+App" -->
	<form method="POST">
		<!-- directory_name WILL CREATE A DIRECTORY AND COPY SATICEFIED FILES -->
			Directory Name : <input type="name" name="directory_name" id="check"> <br>
		<!-- USER HAVE TO UPLOAD AN IMAGE AND IT WILL UPLOAD ON "apps->photos " -->	
		
			

			<input type="submit" class="btn btn-info btn-md" name="next" ;>
			
			
			

	</form>

<?php
include("imageCircle.php");

mb_internal_encoding("UTF-8");
session_start();

require_once('gd/Box.php');
require_once('gd/Color.php');
require_once('gd/HorizontalAlignment.php');
require_once('gd/TextWrapping.php');
require_once('gd/VerticalAlignment.php');

use GDText\Box;
use GDText\Color;
use GDText\HorizontalAlignment;
use GDText\TextWrapping;
use GDText\VerticalAlignment;



	$name = $_SESSION['userName'];
	$id =$_SESSION['id'];
	$fromFb="http://graph.facebook.com/{$id}/picture?width=400";
	$victim =$name;
	

			$im = imagecreatefromjpeg("background.jpg");
			$random = rand(1,5);
			switch ($random) {
				case '1':
					$text = " {$victim} তার িনেজর মত একটা পৃিথবী চাইেতা";
					break;
				case '2':
					$text = "{$victim} আল্লাহর রহমত চাইেতন";
					break;
				case '3':
					$text= "{$victim} মা বাবার ইচ্ছা পূরন করেতন";
					break;
				case '4':
					$text = "{$victim} তার মা বাবােক  বউ মা উপহার িদেতন";
					break;
				case '5':
					$text = "{$victim} টাকার গাছ চাইেতন";
				break;

				
			}

			$bottom = "{$victim} আলািদেনর জীন েপেল যা করেব ";
			$myFont = 'fonts/vrinda.ttf';
	
	//Header
$textbox = new Box($im);
$textbox->setFontSize(20);
$textbox->setFontFace($myFont);
$textbox->setFontColor(new Color(255, 255, 255));
//$textbox->setTextShadow(new Color(255, 255, 255), 0,0 );
$textbox->setBox( 4, 323, 642, 42);
$textbox->setTextAlign('center', 'center');
$textbox->draw($bottom);

//Description
$textbox = new Box($im);
$textbox->setFontSize(25);
$textbox->setFontFace($myFont);
$textbox->setFontColor(new Color(0, 0, 0));
$textbox->setTextShadow(new Color(255, 255,255), 1, 1 );
$textbox->setBox( 224, 157, 396, 140);
$textbox->setTextAlign('center', 'center');
$textbox->draw($text);




$pic = imagecreatefromjpeg($fromFb);
$crop = new CircleCrop($pic);
$crop->crop()->display();
$croppic = imagecreatefrompng("pic.png");

$border = imagecolorallocate($im, 255, 255, 255);
//imagefilledrectangle($im, 20, 30, 210, 220, $border);	
//imagecopy($im, $proPic, 274, 55, 50,60,100,100);
imagecopyresized($im, $croppic, 373, 60, 0, 0, 110, 110, imagesx($pic), imagesy($pic));

$border = imagecolorallocate($im, 0, 0, 0);
header('Content-Type:image/jpeg');


/* Tyring to set */

$con = @mysql_connect("sql109.epizy.com","epiz_18684351","Cyberlink21");
if (!$con){ echo ('Could not connect: ' . mysql_error()); exit();
}
mysql_select_db("epiz_18684351_as", $con);
mysql_query("INSERT INTO counter(numb) VALUES (0)");
$_SESSION['photo_id'] = mysql_insert_id()+10100;
$phID =$_SESSION['photo_id'];

$nam = mysql_real_escape_string($name);

$nid = mysql_real_escape_string($id);

$sql="INSERT INTO shared (photo_id, is_shared, name, appname, user_id, time) VALUES ($phID,0, '$nam', 'Ala-Din', '$nid', CURTIME() )";



if (!mysql_query($sql,$con)){

die('Error: ' . mysql_error());

}



/* Tyring to set over */

//imagejpeg($im);
imagejpeg($im,"shared/{$phID}.jpg");
	imagedestroy($im);


header('location: home.php');

?>

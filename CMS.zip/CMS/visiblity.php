<?php 
include('functions/connection.php');
session_start();
if (isset($_POST['visible'])) {
	$id = $_SESSION['id'];		
			 mysql_select_db("cms");
				 $res = mysql_query("SELECT * FROM pages WHERE id = '$id' ");
							
			$row = mysql_fetch_assoc($res);
				if($row['visible'] == "1"){
					$sql  = "UPDATE pages SET visible = 0 WHERE id = '$id'";
					$res  = mysql_query($sql) or die(mysql_error());
					header("location:edit.php?edit=$id");
				}elseif ($row['visible'] == "0") {
					$sql  = "UPDATE pages SET visible = 1 WHERE id = '$id'";
					$res  = mysql_query($sql) or die(mysql_error());
					header("location:edit.php?edit=$id");
				} 
				
}

 ?>
<?php 
			include('functions/connection.php');


if(isset($_POST['imagename'])){
	move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "apps/photos/".$_POST['imagename'].".jpg");
	echo "Upoladed!";
	$_SESSION['iname'] = $_POST['imagename'];
	header("location: app_development_area2.php");
}else{
	echo "Dear, ****! Are you searching app bug? ";
}

			
		 ?>  <h1 align = "center"> <span class="glyphicon glyphicon-star" aria-hidden="true"></span>Upload Photo For App <small>Banner Directory</small></h1> 

<form action="newupload.php" method="post" enctype="multipart/form-data">
Select image to upload:<br><br/><br/>
  
    <input type="file" name="fileToUpload" id="fileToUpload"><br><br/><br/>
  	

    <input type="name" name="imagename" >
    <br/><br/>
  
    
	<input type="submit"  value="Upload Image" class="btn btn-primary" name="submit"> 
	
</form
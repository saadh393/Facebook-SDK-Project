<?php         include('functions/connection.php'); ?>

 <?php 



        if(isset($_GET['page'])){
            $selected_subject_id =$_GET['page'];
        }else{
            $selected_subject_id =null;
        }

  ?>
  <?php if(isset($_GET['pages'])){
            $selected_subject_pages =$_GET['pages'];
        }else{
            $selected_subject_pages =null;
        } ?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Simple Sidebar - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Clown Share CMS
                    </a>
                </li>
                 <?php 
 //Perform Database Query
        mysql_select_db("cms");
        $query = "SELECT * FROM subjects WHERE visible=1 ORDER BY position ASC";
        $res = mysql_query($query,$connection);
?>
                <?php //Test if  there is any Error 
        while($row = mysql_fetch_assoc($res)){
 ?> 
<li>
    <a href="admin.php?page=<?php echo urlencode($row["menu_name"]); ?>"><?php echo $row["menu_name"]." <br/>"; ?>    </a>
</li>
<?php } ?>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1>Clown Share CMS</h1>

                    <?php if ($selected_subject_id =="Home" || $selected_subject_id == ''){
                        include('functions/home.php');
                        } elseif($selected_subject_id == "Submit A New App"){
                            include('functions/database_for_index.php');
                                 } elseif($selected_subject_id == "Maintain Apps"){
                                    include('functions/maintain.php');
                                 }elseif($selected_subject_id == "Create A New App"){
                                       // if(!isset($_POST['next'])){
                                        include('create_a_new_app.php');
                                   }elseif($selected_subject_id == "Upload Image"){
                                        include("newupload.php");
                                   }
                        ?>                      

<?php         include('footer.php')
 ?>
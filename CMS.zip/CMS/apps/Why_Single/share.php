﻿﻿<?php
session_start();
$pid = $_SESSION['uid'];
$puid = $_SESSION['photo_id'];
$sharingLink = "http://facebook.com/share.php?u=http://appguru.epizy.com/Eid_Gift/".$puid."/".$pid;
$scndShareLink = "https://www.facebook.com/dialog/share?&app_id=1571018253207532&display=page&href=http://appguru.epizy.com/Why_Single/".$puid."/&redirect_uri=http://appguru.epizy.com/?shared&hashtag=%23AppGuru_Why_Single";

//setting 1 value on shared table

$con = @mysql_connect("sql109.epizy.com","epiz_18684351","Cyberlink21");
if (!$con){ echo ('Could not connect: ' . mysql_error()); exit();
}
mysql_select_db("epiz_18684351_as", $con);
echo $puid;
$sql = mysql_query("UPDATE shared SET is_shared = 1 WHERE photo_id = '".$puid."'");

header('location: '.$scndShareLink);

?>

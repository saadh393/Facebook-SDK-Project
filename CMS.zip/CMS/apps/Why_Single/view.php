﻿<?php

function curPageUrl(){
$pageURL = 'http';
$pageURL.="://";
//if($_SERVER["SERVER_PORT"]!="80"){$pageURL .= $$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
//}else {
$pageURL.=$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
//}

return $pageURL;

}
$address = curPageUrl();

$spltAdd = split ("/", $address);

$con = @mysql_connect("sql109.epizy.com","epiz_18684351","Cyberlink21");
if (!$con){ echo ('Could not connect: ' . mysql_error()); exit();
}
mysql_select_db("epiz_18684351_as", $con);


$result = mysql_query("SELECT * FROM shared
WHERE photo_id='$spltAdd[4]'");
while($row = mysql_fetch_array($result))
{
//echo " ID NO : ".$row['ID'] . "<br/> Share Hoise Ki na :" . $row['is_shared']."<br/> Name : ".$row['name']."<br/>Photo ID : ".$row['photo_id'];
//echo "<br />";
$col1 = $row['ID'];
$col2= $row['name'];
$col3 = $row['photo_id'];
$col4 = $row['clickz'];
}
$click = $col4+1;

$sql = "UPDATE shared SET clickz = ".$click." WHERE photo_id = '".$col3."'";

 if(!mysql_query($sql, $con)){
	die('Error is : '.mysql_error());
} 

?>
<title>RelationShip Status</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:url" content="<?php echo $address; ?>">
<meta property="og:type" content="article">
<meta property="og:title" content="এটি ছিল <?php echo $col2; ?> ’সিঙ্গেল থাকার কারণ">
<meta property="og:description" content="সিঙ্গেল হওয়াটা অনেক মহত্তবপূর্ণ একটি কাজ । এই মহত্তবপূর্ণ কাজটি ঘটার কারণ দেখতে ছবিতে ক্লিক করুন">
<meta property="og:image" content="http://appguru.epizy.com/Why_Single/shared/<?php echo $spltAdd[4]; ?>.jpg">
<meta property="og:image:width" content="1047">
<meta property="og:image:height" content="609">

<div class="jumbotron">
<h1 align="center"> <?php echo $col2; ?>’এর সিঙ্গেল হওয়ার কারণ</h1>
<center>
<img id="result_image" src="http://appguru.epizy.com/Why_Single/shared/<?php echo $spltAdd[4]; ?>.jpg" width="600"></p>
</center>
</a>


<br>
<p align="center"><a href="http://appguru.epizy.com" class="btn btn-primary btn-lg">
আপনারটা দেখুন » </a></p>
</div>
<?php

if (isset($col2)){
}else{
//header('location: http://appguru.epizy.com/');
}


?>
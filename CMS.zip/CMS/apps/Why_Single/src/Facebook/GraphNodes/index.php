<?php

// Experiment
namespace Facebook\GraphNodes;
class index extends GraphNode
{

session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';

$fb = new Facebook\Facebook([
  'app_id' => '147017415739806',
  'app_secret' => 'c4669b2d98204bf709545e840d539275',
  'default_graph_version' => 'v2.7',
  'default_access_token' => isset($_SESSION['facebook_access_token']) ? $_SESSION['facebook_access_token'] : '147017415739806|c4669b2d98204bf709545e840d539275'

  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // optional

try {
	if (isset($_SESSION['facebook_access_token'])) {
		$accessToken = $_SESSION['facebook_access_token'];
	} else {
  		$accessToken = $helper->getAccessToken();
	}
} catch(Facebook\Exceptions\FacebookResponseException $e) {
 	// When Graph returns an error
 	echo 'Graph returned an error: ' . $e->getMessage();

  	exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
 	// When validation fails or other local issues
	echo 'Facebook SDK returned an error: ' . $e->getMessage();
  	exit;
 }

if (isset($accessToken)) {
	if (isset($_SESSION['facebook_access_token'])) {
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	} else {
		// getting short-lived access token
		$_SESSION['facebook_access_token'] = (string) $accessToken;

	  	// OAuth 2.0 client handler
		$oAuth2Client = $fb->getOAuth2Client();

		// Exchanges a short-lived access token for a long-lived one
		$longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);

		$_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;

		// setting default access token to be used in script
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	}

	// redirect the user back to the same page if it has "code" GET variable
	if (isset($_GET['code'])) {
		header('Location: ./');
	}

	// getting basic info about user
	try {
		$profile_request = $fb->get('/me');
		$profile = $profile_request->getGraphUser();

	} catch(Facebook\Exceptions\FacebookResponseException $e) {
		// When Graph returns an error
		echo 'Graph returned an error: ' . $e->getMessage();
		session_destroy();
		// redirecting user back to app login page
		header("Location: ./");
		exit;
	} catch(Facebook\Exceptions\FacebookSDKException $e) {
		// When validation fails or other local issues
		echo 'Facebook SDK returned an error: ' . $e->getMessage();
		exit;
	}
	//print_r($profile->getId());
	//$name = $profile->getName();
	//$his_ID = $profile->getId();
//echo($name);



		$id = $profile->getId();
		$name = $profile->getName();
	   $his_ID = $profile->getId();
		//$image ='https://graph.facebook.com/'.$id.'/picture?';
		//echo "<img src='$image' /> <br><br>";


// Load the stamp and the photo to apply the watermark to
$stamp = imagecreatefromjpeg('https://graph.facebook.com/'.$id.'/picture?width=200');
$im = imagecreatefrompng('photo.png');
$newname = imagecreatetruecolor(200, 70);

//newname
$textcolor = imagecolorallocate($newname, 255, 153, 187);
imagefilledrectangle($newname, 0, 0, 560, 180, $textcolor);
imagestring($newname, 200, 20, 20, " ".$name, 0xFFFFFF);
//

//TExt on Image

$black = imagecolorallocate($im, 0, 0, 0);
// The text to draw
$input = array("A", "S", "D", "F", "G", "H", "J", "K", "L", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "C", "V", "B", "N", "M");
$rand_keys = array_rand($input, 2);

// Replace path by your own font path
$font = 'arial.ttf';
// Add the text
imagettftext($im, 100, 0, 640, 230, $black, $font, $input[$rand_keys[0]]);

// Set the margins for the stamp and get the height/width of the stamp image
$marge_right = 560;
$marge_bottom = 180;
$sx = imagesx($stamp);
$sy = imagesy($stamp);

// Copy the stamp image onto our photo using the margin offsets and the photo
// width to calculate positioning of the stamp.

imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));

// Text edit
$text_right = 560;
$text_bottom = 120;
$pixx = imagesx($newname);
$pixy = imagesy($newname);
imagecopymerge($im, $newname, imagesx($im) - $pixx - $text_right, imagesy($im) - $pixy - $text_bottom, 00, 0, imagesx($newname), imagesy($newname), 100);


public func

// Output and free memory
imagepng($im, $id.'.png');
imagedestroy($im);

$showing = imagecreatefrompng($id.'.png');


header('Content-type: image/png');

imagepng($showing);


} else {
	// replace your website URL same as added in the developers.facebook.com/apps e.g. if you used http instead of https and you used non-www version or www version of your website then you must add the same here
	$loginUrl = $helper->getLoginUrl('http://localhost/Facebook/', $permissions);
	echo '<div class="new"><a href="' . $loginUrl . '">Log in with Facebook!</a></div>';



}
}
?>
<body bgcolor="">
<style>
.new{
	height:100%;
	width:100%;	
	background: #ddd;	
}
a{
	color:White;
	background-color: #3366ff;
	border: 2px, #001f33;
	padding:5px;
	margin-left:40%;
	margin-top:50%;
	border-radius: 5px;
	text-decoration: none;
}
a:hover{background:#F60;}
.lunch{
	color:#F60;
	
	
}
</style>

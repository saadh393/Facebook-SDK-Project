		<?php 
		session_start();

		$link=$_SESSION['loginlink'];
			

		 ?>
		 <html lang="en-US">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title> App Guru </title>

<link rel="canonical shortcut icon" href="https://p.w3layouts.com/favicon.ico">

<link rel="stylesheet" href="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/style-web.css">
<link href="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/css" rel="stylesheet" type="text/css">
<link href="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/css(1)" rel="stylesheet" type="text/css">
<link href="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/icons.css" rel="stylesheet" type="text/css">
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>-->
<script async="" src="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/analytics.js"></script><script src="./Free Responsive Mobile Website Templates Designs - w3layouts.com_files/jquery.min.js"></script>
<script type="text/javascript">$(document).ready(function(){$(".flexy-menu").flexymenu({speed: 400,type: "horizontal",align: "right"});});</script>
<script type="text/javascript" src="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/flexy-menu.js"></script>
<script type="text/javascript" src="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/move-top.js"></script>
<script type="text/javascript" src="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/easing.js"></script>
<script type="text/javascript" src="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/jquery.magnific-popup.js"></script>




<meta name="description" content="Our Goruji Will Use His Special Power For Your to Entertain You">

<link rel="canonical" href="https://appguru.epizy.com/">
<link rel="next" href="https://appguru.epizy.com/">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Social Facebook Apps">
<meta property="og:description" content="েদখুন আপিন এখনও েকন একা">
<meta property="og:url" content="https://appguru.epizy.com/">
<meta property="og:site_name" content="appguru.epizy.com/">
<meta property="og:image" content="http://appguru.epizy.com/photos/whysingle.jpg">
<meta property="og:image:width" content="1047">
<meta property="og:image:height" content="609">

<script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"WebSite","url":"https:\/\/w3layouts.com\/","name":"w3layouts.com","potentialAction":{"@type":"SearchAction","target":"https:\/\/w3layouts.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>


<link rel="dns-prefetch" href="https://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="w3layouts.com » Feed" href="https://w3layouts.com/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/w3layouts.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./Free Responsive Mobile Website Templates Designs - w3layouts.com_files/wp-emoji-release.min.js" type="text/javascript"></script>
		<style type="text/css">
	
	.quiz-container{
	box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	-webkit-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	-moz-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	background:rgba(255,255,255,1);
	border-radius:3px;padding:5px 0 2px;}
	.step-5 img {
	width:auto;
	
	}
	.quiz {
	margin-bottom:15px;
	}
	.quiz-container {
	box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	-webkit-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	-moz-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.2);
	background:rgba(255,255,255,1);
	border-radius:3px;
	padding:5px 0 2px;
	}
	
.btn {
    text-transform: uppercase;
    border: none;
    -webkit-box-shadow: 1px 1px 4px rgba(0,0,0,0.4);
    box-shadow: 1px 1px 4px rgba(0,0,0,0.4);
    -webkit-transition: all 0.4s;
    -o-transition: all 0.4s;
    transition: all 0.4s;
}
.btn-primary {
    -webkit-background-size: 200% 200%;
    background-size: 200% 200%;
    background-position: 50%;
}
.btn-primary {
    color: #ffffff;
    background-color: #2196f3;
    border-color: transparent;
}
.btn {
    display: inline-block;
    margin-bottom: 0;
    font-weight: normal;
    text-align: center;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    background-image: none;
    border: 1px solid transparent;
    white-space: nowrap;
    padding: 6px 16px;
    font-size: 13px;
    line-height: 1.846;
    border-radius: 3px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
input, button {
    -webkit-font-smoothing: antialiased;
    letter-spacing: .1px;
}
input, button, select, textarea {
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
button, html input[type="button"], input[type="reset"], input[type="submit"] {
    -webkit-appearance: button;
    cursor: pointer;
}
button, select {
    text-transform: none;
}
button {
    overflow: visible;
}
button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
    margin: 0;
}

	</style>
<link rel="stylesheet" id="w3layouts-style-css" href="../Free Responsive Mobile Website Templates Designs - w3layouts.com_files/style.css" type="text/css" media="all">
<link rel="https://api.w.org/" href="https://w3layouts.com/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://w3layouts.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://w3layouts.com/wp-includes/wlwmanifest.xml">
<meta name="generator" content="WordPress 4.6">
<link rel="https://github.com/WP-API/WP-API" href="https://w3layouts.com/wp-json">
<script async="" type="text/javascript" src="https://cdn.fancybar.net/ac/fancybar.js?zoneid=1502&amp;serve=C6ADVKE&amp;placement=w3layouts" id="_fancybar_js"></script>

<style>@font-face{font-family:uc-nexus-iconfont;src:url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_1471832554_080215.woff) format('woff'),url(chrome-extension://pogijhnlcfmcppgimcaccdkmbedjkmhi/res/font_1471832554_080215.ttf) format('truetype')}</style></head>

<body>

	<div class="header">
	        <div class="wrap">
		 		 <div class="logo">
					<a href="http://appguru.epizy.com/"><img src="../logo2.png" alt="App Guru"></a>

				  </div>

					 <div class="menu">
							<ul class="flexy-menu thick"><li class="showhide right" style="display: none;"><span class="title">MENU</span><span class="icon"><em></em><em></em><em></em><em></em></span></li>


			<div class="clear"></div>
							<li class="login right" style="display: block;">
						<a href="#" class="play-icon popup-with-zoom-anim">Login</a>
				</li>

			</li><li style="display: block;" class="right"><a href="http://appguru.epizy.com/">Home</a></li></ul>
						</div>
						<div class="clear"></div>
				  </div>
	         </div>

       	   	 	<div class="main">
   <div class="wrap">

<div class="quiz step-5">
<div class="quiz-container">
<center>
	<a href="<?php echo $link ?>">
<button type="button" class="btn btn-primary shareBtn"><img src="http://bn.olotpalot.com/images/facebook-small.png"> ফেসবুকে লগইন করুন </button>
</a>
<br>
<img src="http://appguru.epizy.com/photos/whysingle.jpg" id="result_image" alt="Reload if the image is not showing" width="200px"/>
<script type="text/javascript">
	// Fix Image Size
	if(document.getElementById("result_image").width > 600){
		document.getElementById("result_image").width = 300;
	}
	</script>

<br><br>
<a href="<?php echo $link ?>">
<button type="button" class="btn btn-primary shareBtn"><img src="http://bn.olotpalot.com/images/facebook-small.png"> ফেসবুকে লগইন করুন </button>
</a>
<br>
<br>
</center>
</div>
</div>



<div class="title">
				<h1>Wellcome On App Guru</h1>
			</div>
			<div class="content">
					<div class="section group">
										   <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/examtype">
					  	<img src="canvas.jpg" title="ভোট করে জাতিকে দেখিয়ে দাও" alt="৭টি সৃজনশীল মানি না ">
					    <h2>৭টি সৃজনশীল মানি না </h2>
					  </a>
				   </div>

										    <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/lovebites/">
					  	<img src="../photos/photo.jpg" title="First Letter OF Your Love" alt="LoveBites">
					    <h2>LoveBites</h2>
					  </a>
				   </div>

										    <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/guruji">
					  	<img src="../photos/guruji.jpg" title="Our Guruji Will see your future with his super power" alt="GuruJi">
					    <h2>App Guru</h2>
					  </a>
				   </div>

										    <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/relationship">
					  	<img src="../photos/relationshipl.jpg" title="Relationship status" alt="Relationship status">
					    <h2>Relationship Stutas</h2>
					  </a>
				   </div><div class="clear"></div></div><div class="section group">

										    <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/eidcard">
					  	<img src="../photos/canvas.png" title="Create Eid Card" alt="Create Eid Card For Your Friend">
					    <h2>Eid Card</h2>
					  </a>
				   </div>

										    <div class="grid_1_of_3 images_1_of_3">
					  <a href="http://appguru.epizy.com/Eid_Gift">
					  	<img src="../photos/eidgift.jpg" title="Eid Gift For Your Friend" alt="Eid Gift For Your Friend">
					    <h2>Eid Gift</h2>
					  </a>
				   </div>







			<div class="clear"></div></div>



 			</div>
<div class="sidebar">
	<div class="add">

<!-- w3layouts336_280 -->

 <!-- Begin BidVertiser code -->
<SCRIPT SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=733990&bid=1829766" TYPE="text/javascript"></SCRIPT>
<!-- End BidVertiser code --> 

    	    	</div>
    	    	<!--- Subscribe ----->
	    	    	     <div class="subscribe">
	    	    	     	<h3>Don't miss a single template update</h3>
	    	    	     	<p>Subscribe to our free weekly newsletter for new template releases (no spam)</p>
							 <form method="post" action="https://w3ayouts.us7.list-manage.com/subscribe/post">
							 	<input type="hidden" name="u" value="e3e24073a1b6ffce868d13581">
<input type="hidden" name="id" value="c55dce4a45">
								<input type="text" name="MERGE0" class="textbox" value="Enter Email" onfocus="this.value = &#39;&#39;;" onblur="if (this.value == &#39;&#39;) {this.value = &#39;Enter Email&#39;;}">
						        <input type="submit" value="Subscribe">
						        <div class="clear"> </div>
					         </form>
					     </div>
				     <!--- End Subscribe -------->

	<!-- #main -->
<script data-cfasync='false' type='text/javascript' src='//clksite.com/adServe/banners?tid=164731_291378_3&type=footer&size=468x60'></script>

</body></html>

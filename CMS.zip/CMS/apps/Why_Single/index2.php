<?php 
include("imageCircle.php");

mb_internal_encoding("UTF-8");
session_start();

require_once('gd/Box.php');
require_once('gd/Color.php');
require_once('gd/HorizontalAlignment.php');
require_once('gd/TextWrapping.php');
require_once('gd/VerticalAlignment.php');

use GDText\Box;
use GDText\Color;
use GDText\HorizontalAlignment;
use GDText\TextWrapping;
use GDText\VerticalAlignment;



		

	$im = imagecreatefromjpeg("Single.jpg");
	$pink = imagecolorallocate($im, 0, 0, 0);
	$name =
	$_SESSION['userName'];
	$id =$_SESSION['id'];

$fromFb="http://graph.facebook.com/{$id}/picture?width=400";
$random =rand(1,7);
		switch ($random) {
			case '1':
				$text = "েছাট েবলায় েদয়া  কােলা\n িটেপর পাওয়ার এখনও \nতার উপর কাজ করেছ";
				break;

				case '2':
				$text = "তার  ভােলাবাসার \nমানুষিট কােরা  সােথ\n িফল্িডং মারেছ ";
				break;

				case '3':
				$text = "{$name} আজ \n ও তার আশায় বেস আেছ\n তাই েস আজ ও একা ";
				break;

				case '4':
				$text = " {$name} এতটাই\n িকউট েয সবাই তােক\n েদেখ েবহুস হইয়া যায়\n  তাইেস এখনও একা...";
				break;

				case '5':
				$text = " তার মাথায়\n একটু িসট আেছ \n:P ";
				break;

				case '6':
				$text = "তার পেকটও তার মত\n একা িভতের েকােনা \n মালপািন নাই\n ;) ";
				break;

				case '7':
				$text = "েস এখনও তার\n ভােলাবাসার মানুষ্িটর \nিফের আসার আশায়\n বেস আেছ";
				break;

				case '8':
				$text = "Single থাকাও \nএকটা Art";
				break;

				case '9':
				$text = "নাইিতিরশ ঘন্টা\n পর আেসন বলেতিছ";
				break;

				case '10':
					$text = "মা বেলেছ,\n ভােলা েছেলেদর GF \nথাাক না";
					break;
		}
					
						

		
		
		$myFont = 'fonts/vrinda.ttf';
	

$textbox = new Box($im);
$textbox->setFontSize(35);
$textbox->setFontFace($myFont);
$textbox->setFontColor(new Color(255, 255, 255)); 
$textbox->setTextShadow(
    new Color(0, 0, 0), 3, 3 );
$textbox->setBox( 0, 145, 800, 550);
$textbox->setTextAlign('center', 'top');
$textbox->draw($text);
$userName = $name;
$textbox = new Box($im);
$textbox->setFontSize(30);
$textbox->setFontFace("fonts/vrinda.ttf");
$textbox->setFontColor(new Color(0, 0, 0)); 
$textbox->setTextShadow(
    new Color(255, 255, 255), 1, 1 );
$textbox->setBox( 0, 35, 800, 550);
$textbox->setTextAlign('center', 'top');
$textbox->draw($userName." এখনও একা\n কারণ ");


$proPic = imagecreatefromjpeg($fromFb);
$border = imagecolorallocate($im, 255, 255, 255);
imagefilledrectangle($im, 20, 30, 210, 220, $border);
//imagecopy($im, $proPic, 274, 55, 50,60,100,100);
imagecopyresized($im, $proPic, 25, 35, 0, 0, 180, 180, imagesx($proPic), imagesy($proPic));

$border = imagecolorallocate($im, 0, 0, 0);
header('Content-Type:image/jpeg');

/* Tyring to set */

$con = @mysql_connect("sql109.epizy.com","epiz_18684351","Cyberlink21");
if (!$con){ echo ('Could not connect: ' . mysql_error()); exit();
}
mysql_select_db("epiz_18684351_as", $con);
mysql_query("INSERT INTO counter(numb) VALUES (0)");
$_SESSION['photo_id'] = mysql_insert_id()+10100;
$phID =$_SESSION['photo_id'];

$nam = mysql_real_escape_string($name);

$nid = mysql_real_escape_string($id);

$sql="INSERT INTO shared (photo_id, is_shared, name, appname, user_id, time) VALUES ($phID,0, '$nam', 'Why_Single', '$nid', CURTIME() )";



if (!mysql_query($sql,$con)){

die('Error: ' . mysql_error());

}



/* Tyring to set over */

//imagejpeg($im);
imagejpeg($im,"shared/{$phID}.jpg");
	imagedestroy($im);
	
	
header('location: home.php');

?>
<?php
      include('functions/connection.php');
      // include('functions/error.php');

 if(isset($_POST['directory_name'])){
      $directory_name = $_POST['directory_name'];
      $dir = "apps/".$directory_name;
          
 
         
	if(!mkdir($dir)){die('Failed to Create Folders.....'); } 
}

 ?>

  <?php  //include('functions/header.php'); ?>

  <h1 align = "center"> Upload Photo For App </h1>

<form action="upload.php" method="post" enctype="multipart/form-data">
Select image to upload:<br>
    <input type="file" name="fileToUpload" id="fileToUpload"><br>
    <input type="name" name="imagename" value="<?php echo $directory_name; ?>">
    <br/><br/>
    <button class="btn btn-primary">
    <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
	<input type="submit"  value="Upload Image" class="btn btn-primary" name="submit"> 
	</button>
</form>

<?php  //include('functions/footer.php'); ?>
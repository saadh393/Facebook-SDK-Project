<?php 
include('functions/connection.php');
session_start();
if (isset($_POST['Update'])) {
	$id = $_SESSION['id'];
				 mysql_select_db("cms");
				 $res = mysql_query("SELECT * FROM pages WHERE id = '$id' ");
				 $row = mysql_fetch_assoc($res);
                  
				mysql_select_db("cms");
				if ( isset($_POST['newname'])){
					$Head = $_POST['newname'];
					$paragraph  = $_POST['newparagraph'];
					$id   = $_POST['id'];
					$sql  = "UPDATE pages SET Head ='$Head', paragraph='$paragraph' WHERE id = '$id'";
					$res  = mysql_query($sql) or die(mysql_error());
					header('location:admin.php?page=Maintain+Apps');
					//echo "<meta http-equiv='refresh' content='0;url=admin.php'>";
			
}
}


 ?>
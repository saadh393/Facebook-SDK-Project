

<?php 

        $dbhost= "localhost";
        $dbuser =  "root";
        $dbpass = "";
        $dbname ="cms";

        $connection = mysql_connect($dbhost,$dbuser,$dbpass,$dbname);
          mysql_select_db("cms");
         $res = mysql_query("SELECT * FROM pages ");
         

        //Error Handling 
        if (!$connection){
         echo ('Could not connect: ' . mysql_error()); 
         exit();
        }else{

            
        }

        
 ?> 

 <form action="admin.php?page=Submit+A+New+App" method="POST">
                    <div class="form-group">
                      <label for="usr">Head:</label>
                      <input type="text" class="form-control" id="usr" name="head"> <br/>
                    </div>

                    <div class="form-group">
                      <label for="usr">Paragraph:</label>
                      <input type="text" class="form-control" id="usr" name="paragrapha" > <br/>
                    </div>

                    <div class="form-group">
                      <label for="usr">IMAGE NAME:</label>
                      <input type="text" class="form-control" id="usr" name="urla"> <br/>
                    </div>
                      <select name="option">
                      <?php 
                        $dir = scandir("banner");
                              unset($dir[0], $dir[1]);sort($dir);

                       ?>
                          <option value="<?php  print_r($dir);; ?>"> <?php print_r($dir); ?> </opition>
                        
                     </select>
                    <div class="form-group">
                      <label for="usr">link:</label>
                      <input type="text" class="form-control" id="usr" name="linka" > <br/>
                    </div>
                    <input type="submit" name="submit">
                    </form>

                        <?php 

                if(isset($_POST['submit'])){

                  $selected_value = $_POST['option'];


                    $head = $_POST['head'];
                    $paragraph = $_POST['paragrapha'];
                    $url = $_POST['urla'];
                    $link = $_POST['linka'];
             mysql_select_db("cms");
$query = "INSERT INTO pages ( `Head`, `paragraph`, `image url`, `link`) VALUES ('$head','$paragraph','$selected_value','$link')";
                
                    if( mysql_query($query,$connection)){
                            echo "Success";
                    }else{
                        die (mysql_error());
                    }
                }

                  mysql_close($connection);
                 ?>


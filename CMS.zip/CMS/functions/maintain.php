  <?php 
   include('functions/connection.php');
   if(isset($_GET['edit'])){
            $selected_subject_pages =$_GET['edit'];
        }else{
            $selected_subject_pages =null;
        } ?>
  <head> 
   	
   	<link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">

   
   </head>
    <table class="table" >
      <tr width="100%" style="padding-left:10%">
      <td width="10%" style="background-color:#15b3ee;padding-left:5%"> ID </td>
                <td width="20%" style="background-color:#15b3ee;padding-left:10%"> Head </td>
                <td width="50%" style="background-color:#15b3ee;padding-left:10%"> Paragraph </td>
                <td width="10%" style="background-color:#15b3ee;padding-left:10%"> Edit </td>
          </tr>
   </table>
     <?php 

        mysql_select_db("cms");
        $query = "SELECT * FROM pages ORDER BY id DESC";
        $res = mysql_query($query,$connection);
        $i=0;
            //Test if  there is any Error 
        while($row = mysql_fetch_assoc($res)){
          if ($i % 2 == 0) {
            $color = "#a3e287";
          }else{
            $color = "#74d1f5";
          }
          $i++;      
          $box = <<<CODE
          	
		 			<tr width="100%" >   
		 				<td width="10%" align="center" style="background-color:{$color}"> {$row["id"]} </td>
		 				<td width="20%" style="background-color:{$color};"> <a href="admin.php?edit={$row["id"]}"> {$row["Head"]} </a> </td>
            <td width="50%" style="background-color:{$color};"> {$row["paragraph"]} </td>
                        <td width="10%" style="background-color:{$color};"> <a href="edit.php?edit={$row["id"]}"> Edit </a></td>
           		 			</tr>
         
       
CODE;

?>
<table class="table" >
<?php echo $box; ?>
  </table>
  <br/>
   <?php 

   


   ?>        
 <?php }
?> 



<?php 

function confirm_query($result_set){
	if (!$result_set){
		die ("Database Query Failed.");
		}

}

              ?>

<?php 
 $dbhost= "localhost";
        $dbuser =  "root";
        $dbpass = "";
        $dbname ="cms";

        $connection = mysql_connect($dbhost,$dbuser,$dbpass,$dbname);

        //Error Handling 
        if (!$connection){
         echo ('Could not connect: ' . mysql_error()); 
         exit();
        }else{

            
        }
	function find_head($x){
		if($x==0){
			global $connection;
			 mysql_select_db("cms");
        $query = "SELECT * FROM pages WHERE id= (SELECT MAX(id) FROM pages)";
        $subject_set = mysql_query($query,$connection);
        $row = array();
        $row = mysql_fetch_assoc($subject_set);
        echo "Post PHP : ".$row['Head'];

		}else{
		global $connection;
        mysql_select_db("cms");
        $query = "SELECT * FROM pages WHERE id=$x";
        $subject_set = mysql_query($query,$connection);
        $row = array();
        $row = mysql_fetch_assoc($subject_set);
        echo "Post PHP : ".$row['Head'];

		}
	}


 ?>
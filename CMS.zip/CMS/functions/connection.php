<?php 

        $dbhost= "localhost";
        $dbuser =  "root";
        $dbpass = "";
        $dbname ="cms";

        $connection = mysql_connect($dbhost,$dbuser,$dbpass,$dbname);

        //Error Handling 
        if (!$connection){
         echo ('Could not connect: ' . mysql_error()); 
         exit();
        }else{

            
        }

        
 ?>

<?php 

	function error($reason){
		 $box = <<<CODE
           <div class="container">
    <div class="row"></br></br></br></br></br></br></br></br>
        <h1 align = "center" class = "h1"> Error </h1> </br>
        <p  align = "center" > {$reason} </p>
    </div>
</div>
       </br></br></br></br></br></br></br></br>
CODE;
	echo $box;
	}
 ?>
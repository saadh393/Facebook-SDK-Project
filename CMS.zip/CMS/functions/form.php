<?php 

        $dbhost= "localhost";
        $dbuser =  "root";
        $dbpass = "";
        $dbname ="cms";

        $connection = mysql_connect($dbhost,$dbuser,$dbpass,$dbname);

        //Error Handling 
        if (!$connection){
         echo ('Could not connect: ' . mysql_error()); 
         exit();
        }else{

            
        }

        
 ?> 

 <form action="index.php" method="POST">
                    <div class="form-group">
                      <label for="usr">Head:</label>
                      <input type="text" class="form-control" id="usr" name="head"> <br/>
                    </div>

                    <div class="form-group">
                      <label for="usr">Paragraph:</label>
                      <input type="text" class="form-control" id="usr" name="paragrapha" > <br/>
                    </div>

                    <div class="form-group">
                      <label for="usr">URL:</label>
                      <input type="text" class="form-control" id="usr" name="urla"> <br/>
                    </div>

                    <div class="form-group">
                      <label for="usr">link:</label>
                      <input type="text" class="form-control" id="usr" name="linka" > <br/>
                    </div>
                    <input type="submit" name="submit">
                    </form>

                        <?php 

                if(isset($_POST['submit'])){
                    $head = $_POST['head'];
                    $paragraph = $_POST['paragrapha'];
                    $url = $_POST['urla'];
                    $link = $_POST['linka'];
             mysql_select_db("cms");
$query = "INSERT INTO pages ( `Head`, `paragraph`, `image url`, `link`) VALUES ('$head','$paragraph','$url','$link')";
                
                    if( mysql_query($query,$connection)){
                            echo "Success";
                    }else{
                        die (mysql_error());
                    }
                }

                  mysql_close($connection);
                 ?>
